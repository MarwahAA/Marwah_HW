/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myreflexagent;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;
import java.util.*;

/**
 *
 * @author 1
 */
public class MyReflexAgent {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input=new Scanner(System.in);
            int rows,cols,dirt;
            ArrayList<Integer> rDirt = new ArrayList<Integer>();
            ArrayList<Integer> cDirt = new ArrayList<Integer>();
            
            System.out.println("Enter the number of Rows: ");
            rows = input.nextInt();
            System.out.println("Enter the number of Columns: ");
            cols = input.nextInt();
            System.out.println("Enter the number of Dirty cells: ");
            dirt = input.nextInt();
            
            Environment env = new Environment(rows,cols,dirt);
            
            //Scan for dirt
            for(int i=0;i<rows;i++){
                if(i!=0 ){
                    env.moveDown();
                }
                for(int j=0;j<cols;j++){
                    boolean x = env.isDirty();
                    if(x==true){
                        rDirt.add(env.getRow());
                        cDirt.add(env.getColumn());
                    }
                    
                    if(j!=(cols-1)){
                    
                        if(i==0 || i%2==0){
                            env.moveRight();
                        }
                        else{
                            env.moveLeft();
                        }
                }
                }
            }
            
            env.reset();
            System.out.println("\nEnvironment before cleaning:");
            System.out.println(env.toString());

            System.out.println("\nLocations of Dirt:");
            for(int i=0;i<rDirt.size();i++){
                System.out.println("("+rDirt.get(i)+","+cDirt.get(i)+")");
            }
            
            
            //Clean dirt
                int numSuck =0;
                int maxNumDirections=4;
                while (numSuck < rDirt.size()) {

 
                    Random generator = new Random();

                    int randDirection = generator.nextInt(maxNumDirections);


                    switch (randDirection) {

                        case 0:

                            while (env.getColumn() != cols - 1) {

                                if (env.isDirty()) {

                                    env.suck();

                                    System.out.println("\nClean:");

                                    System.out.println(env.toString());

                                    numSuck++;

                                }

                                env.moveRight();

                                System.out.println("\nMove Right:");

                                System.out.println(env.toString());

                            }

                            break;


                        case 1:

                            while (env.getColumn() != 0) {

                                if (env.isDirty()) {

                                    env.suck();

                                    System.out.println("\nClean:");

                                    System.out.println(env.toString());

                                    numSuck++;

                                }

                                env.moveLeft();

                                System.out.println("\nMove Left:");

                                System.out.println(env.toString());

                            }

                            break;


                        case 2:

                            while (env.getRow() != rows - 1) {

                            if (env.isDirty()) {

                                env.suck();

                                System.out.println("\nClean:");

                                System.out.println(env.toString());

                                numSuck++;

                            }

                            env.moveDown();

                            System.out.println("\nMove Down:");

                            System.out.println(env.toString());

                            }

                            break;


                        case 3:

                            while (env.getRow() != 0) {

                            if (env.isDirty()) {

                                env.suck();

                                System.out.println("\nClean:");

                                System.out.println(env.toString());

                                numSuck++;

                            }

                            env.moveUp();

                            System.out.println("\nMove Up:");

                            System.out.println(env.toString());

                            }

                            break;

                    }

           
            
            
        }
            System.out.println("\nEnvironment after cleaning:");
            System.out.println(env.toString());
            System.out.println("\nNumber time of Suck:"+numSuck);
            System.out.println("Score: "+env.getScore());
            
    }
}
