/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mytableagent;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author missmarwah
 */
public class MyTableAgent {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            Scanner input=new Scanner(System.in);
            int rows,cols,dirt;
            
            
            rows = 5;
            cols = 5;
            System.out.println("The space is 5X5 \nEnter the number of Dirty cells : ");
            dirt = input.nextInt();
            
            Environment env = new Environment(rows,cols,dirt);
            System.out.println("\nEnvironment before cleaning:");
            System.out.println(env.toString());
            
            for(int i=0;i<rows;i++){
                for(int j=0;j<cols;j++){
                    int g;
                    g=table(i,j);
                    if (g==0){//move right
                        
                        
                        boolean x = env.isDirty();
                        if (x==true){
                            env.suck();
                            
                            System.out.println("\nClean:");
                            System.out.println(env.toString());
                            j=j-1;
                        }else{
                                env.moveRight();
                                System.out.println("\nMove right:");
                                System.out.println(env.toString());
                                
                            }
                        }
                    
                    if (g==1){//move down
                        
                         boolean x = env.isDirty();
                            if (x==true){
                                env.suck();
                                System.out.println("\nClean");
                                System.out.println(env.toString());
                            j=j-1;}
                            
                        else{
                            env.moveDown();
                            System.out.println("\nMove down:");
                            System.out.println(env.toString());
                        }
                    }
                    if (g==2){//move left
                        
                    boolean x = env.isDirty();
                        if (x==true){
                            env.suck();
                            System.out.println("\nClean:");
                            System.out.println(env.toString());
                            j=j-1;
                             
                        }else{
                            env.moveLeft();
                            System.out.println("\nMove Left");
                            System.out.println(env.toString());
                            }
                    }
                    if (g==3){//stop
                        
                    boolean x = env.isDirty();
                        if (x==true){
                            env.suck();
                            System.out.println("\nClean:");
                            System.out.println(env.toString());
                        }
                }
            }}

           
            

            
            System.out.println("\nEnvironment after cleaning:");
            System.out.println(env.toString());
            System.out.println("Score: "+env.getScore());
        }
 public static int table(int row, int col){
      int s = 0;          
if (row==0){
                if(col==0)
                    s= 0;//right
                if(col==1)
                    s= 0;//right
                if(col==2)
                    s= 0;//right
                if(col==3)
                    s= 0;//right
                if(col==4)
                    s= 1;//down

}

if (row==1){
                if(col==0)
                    s= 2;//left
                if(col==1)
                    s= 2;//left
                if(col==2)
                    s= 2;//left
                if(col==3)
                    s= 2;//left
                if(col==4)
                    s= 1;//down

}

if (row==2){
                if(col==0)
                    s= 0;//right
                if(col==1)
                    s= 0;//right
                if(col==2)
                    s= 0;//right
                if(col==3)
                    s= 0;//right
                if(col==4)
                    s= 1;//down

}
if (row==3){
                if(col==0)
                    s= 2;//left
                if(col==1)
                    s= 2;//left
                if(col==2)
                    s= 2;//left
                if(col==3)
                    s= 2;//left
                if(col==4)
                    s= 1;//down

}
if (row==4){
                if(col==0)
                    s= 0;//right
                if(col==1)
                    s= 0;//right
                if(col==2)
                    s= 0;//right
                if(col==3)
                    s= 0;//right
                if(col==4)
                    s= 3;//stop

}
        return s;
 }           
}

