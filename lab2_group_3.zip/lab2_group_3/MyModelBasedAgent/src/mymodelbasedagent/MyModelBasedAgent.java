/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mymodelbasedagent;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author missmarwah
 */
public class MyModelBasedAgent {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner input=new Scanner(System.in);
            int rows,cols,dirt;
            
            
            System.out.println("Enter the number of Rows: ");
            rows = input.nextInt();
            System.out.println("Enter the number of Columns: ");
            cols = input.nextInt();
            System.out.println("Enter the number of Dirty cells: ");
            dirt = input.nextInt();
            
            Environment env = new Environment(rows,cols,dirt);
            
           
            System.out.println("\nEnvironment before cleaning:");
            System.out.println(env.toString());

            for(int i=0;i<rows;i++){
                 //move down
                 if(i!=0){
                        
                            
                         
                            
                        
                            env.moveDown();
                            System.out.println("\nMove down:");
                            System.out.println(env.toString());
                        
                       // t=t+1;
                        //}
            }
                for(int j=1;j<cols;j++){
                    int g;
                    g=i%2;
                    if (g==0){//move right
                        
                        
                        boolean x = env.isDirty();
                        if (x==true){
                            env.suck();
                            
                            System.out.println("\nClean:");
                            System.out.println(env.toString());
                            j=j-1;
                            
                        }else{
                                env.moveRight();
                                System.out.println("\nMove right:");
                                System.out.println(env.toString());
                                
                            
                        }}
                    
                   
                    if (g!=0){//move left
                        
                    boolean x = env.isDirty();
                        if (x==true){
                            env.suck();
                            System.out.println("\nClean:");
                            System.out.println(env.toString());
                            j=j-1;
                             
                        }else{
                            env.moveLeft();
                            System.out.println("\nMove Left");
                            System.out.println(env.toString());
                            
                            
                    }}
                   
            }
            
                   }

           
            

            
            System.out.println("\nEnvironment after cleaning:");
            System.out.println(env.toString());
            System.out.println("Score: "+env.getScore());
        }
}
